import Header from "../../components/Header/Header"
import Card from "../../components/Card/Card"
import Nav from "../../components/Nav/Nav"
import TituloHeader from "../../components/TituloHeader/TituloHeader"
import { SectionCard } from "./styled"
import menu from "../../assets/menu.png"
import search from "../../assets/search.png"


function Home(props){
    return(
        <>
            <Header
            pagina={props.pagina}
            imgPrimeira={menu}
            imgSegunda={search}
            />
            <TituloHeader/>
            <Nav/>

            <SectionCard>
                <Card/>
                <Card/>
                <Card/>
                <Card/>
            </SectionCard>

            <SectionCard>
                <Card/>
            </SectionCard>
        </>
    )

}
export default Home