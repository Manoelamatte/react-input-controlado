import { CardContainer, Divcard, ImagemCard, TextCard, TituloCard } from "./styled"

function Card(){

return(
   <CardContainer>

    <ImagemCard src=""/>

        <TituloCard>
            Unicorn Sprinkles
        </TituloCard>
        <TextCard>
            Strawberry creamy...
        </TextCard>

        <Divcard>
            <p>7.800</p>
            <a>Mais</a>
        </Divcard>
        
   </CardContainer>
)

}

export default Card