import { Detalhes } from "./styled"


function TituloHeader(){

    return(
        <>
        <TituloHeader> Some sweets of
            <Detalhes>
                Happiness!
            </Detalhes>
        </TituloHeader>
        
        
        </>
    )
}

export default TituloHeader